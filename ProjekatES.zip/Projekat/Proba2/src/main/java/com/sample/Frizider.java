package com.sample;

public class Frizider {
	
	private String svetlo;
	private String zvukVent;
	private String zvukKomp;
	private String problem = "Za Vase unete vrednosti ne postoji resenje. Pogledajte uputstvo.";
	private String napajanje;
	private String mrtavFrizider;
	private String vrednostTermostata;
	private String motorKompresor;
	private String hladiFrizider;
	private String odmzavanje;
	private String zavojnice;
	private String ventilator;
	private String buka;
	private String ventKond;
	private String lopticeVentilatora;
	private String elektricniMotorUnutarVremenskogSklopa;
	private String posudaZaIsparavanje;
	private String curenje;
	private String cev;
	private String odvod;
	private String prekidac;
	private String instalacijaPremaRasprsivacu;
	private String temperaturaFrizidera;
	private String termostat;
	private String zicaLedomata;
	private String vrataFrizidera;
	private String protokVode;
		
	public String getSvetlo() {
		return svetlo;
	}
	public void setSvetlo(String svetlo) {
		this.svetlo = svetlo;
	}
	public String getZvukVent() {
		return zvukVent;
	}
	public void setZvukVent(String zvukVent) {
		this.zvukVent = zvukVent;
	}
	public String getZvukKomp() {
		return zvukKomp;
	}
	public void setZvukKomp(String zvukKomp) {
		this.zvukKomp = zvukKomp;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	
	public String getNapajanje() {
		return napajanje;
	}
	public void setNapajanje(String napajanje) {
		this.napajanje = napajanje;
	}
	public String getMrtavFrizider() {
		return mrtavFrizider;
	}
	public void setMrtavFrizider(String mrtavFrizider) {
		this.mrtavFrizider = mrtavFrizider;
	}
	public String getVrednostTermostata() {
		return vrednostTermostata;
	}
	public void setVrednostTermostata(String vrednostTermostata) {
		this.vrednostTermostata = vrednostTermostata;
	}
	public String getMotorKompresor() {
		return motorKompresor;
	}
	public void setMotorKompresor(String motorKompresor) {
		this.motorKompresor = motorKompresor;
	}
	public String getHladiFrizider() {
		return hladiFrizider;
	}
	public void setHladiFrizider(String hladiFrizider) {
		this.hladiFrizider = hladiFrizider;
	}
	public String getOdmzavanje() {
		return odmzavanje;
	}
	public void setOdmzavanje(String odmzavanje) {
		this.odmzavanje = odmzavanje;
	}
	public String getZavojnice() {
		return zavojnice;
	}
	public void setZavojnice(String zavojnice) {
		this.zavojnice = zavojnice;
	}
	public String getVentilator() {
		return ventilator;
	}
	public void setVentilator(String ventilator) {
		this.ventilator = ventilator;
	}
	public String getBuka() {
		return buka;
	}
	public void setBuka(String buka) {
		this.buka = buka;
	}
	public String getVentKond() {
		return ventKond;
	}
	public void setVentKond(String ventKond) {
		this.ventKond = ventKond;
	}
	public String getLopticeVentilatora() {
		return lopticeVentilatora;
	}
	public void setLopticeVentilatora(String lopticeVentilatora) {
		this.lopticeVentilatora = lopticeVentilatora;
	}
	public String getElektricniMotorUnutarVremenskogSklopa() {
		return elektricniMotorUnutarVremenskogSklopa;
	}
	public void setElektricniMotorUnutarVremenskogSklopa(String elektricniMotorUnutarVremenskogSklopa) {
		this.elektricniMotorUnutarVremenskogSklopa = elektricniMotorUnutarVremenskogSklopa;
	}
	public String getPosudaZaIsparavanje() {
		return posudaZaIsparavanje;
	}
	public void setPosudaZaIsparavanje(String posudaZaIsparavanje) {
		this.posudaZaIsparavanje = posudaZaIsparavanje;
	}
	public String getCurenje() {
		return curenje;
	}
	public void setCurenje(String curenje) {
		this.curenje = curenje;
	}
	public String getCev() {
		return cev;
	}
	public void setCev(String cev) {
		this.cev = cev;
	}
	public String getOdvod() {
		return odvod;
	}
	public void setOdvod(String odvod) {
		this.odvod = odvod;
	}
	public String getPrekidac() {
		return prekidac;
	}
	public void setPrekidac(String prekidac) {
		this.prekidac = prekidac;
	}
	public String getInstalacijaPremaRasprsivacu() {
		return instalacijaPremaRasprsivacu;
	}
	public void setInstalacijaPremaRasprsivacu(String instalacijaPremaRasprsivacu) {
		this.instalacijaPremaRasprsivacu = instalacijaPremaRasprsivacu;
	}
	public String getTemperaturaFrizidera() {
		return temperaturaFrizidera;
	}
	public void setTemperaturaFrizidera(String temperaturaFrizidera) {
		this.temperaturaFrizidera = temperaturaFrizidera;
	}
	public String getTermostat() {
		return termostat;
	}
	public void setTermostat(String termostat) {
		this.termostat = termostat;
	}
	public String getZicaLedomata() {
		return zicaLedomata;
	}
	public void setZicaLedomata(String zicaLedomata) {
		this.zicaLedomata = zicaLedomata;
	}
	public String getVrataFrizidera() {
		return vrataFrizidera;
	}
	public void setVrataFrizidera(String vrataFrizidera) {
		this.vrataFrizidera = vrataFrizidera;
	}
	public String getProtokVode() {
		return protokVode;
	}
	public void setProtokVode(String protokVode) {
		this.protokVode = protokVode;
	}
	
	
	public String toString() {
		
		return problem;
	}
	
	

}
