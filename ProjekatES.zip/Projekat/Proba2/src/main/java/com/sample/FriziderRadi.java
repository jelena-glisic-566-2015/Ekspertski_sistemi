package com.sample;

public class FriziderRadi {
	
	private String svetlo;
	private String zvukVent;
	private String zvukKomp;
	private String fRadi;
	private String problem;
	
	public String getSvetlo() {
		return svetlo;
	}
	public void setSvetlo(String svetlo) {
		this.svetlo = svetlo;
	}
	public String getZvukVent() {
		return zvukVent;
	}
	public void setZvukVent(String zvukVent) {
		this.zvukVent = zvukVent;
	}
	public String getZvukKomp() {
		return zvukKomp;
	}
	public void setZvukKomp(String zvukKomp) {
		this.zvukKomp = zvukKomp;
	}
	public String getFRadi() {
		return fRadi;
	}
	public void setFRadi(String fRadi) {
		
		this.fRadi = fRadi;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	
public String toString() {
		
		return problem;
	}

}
