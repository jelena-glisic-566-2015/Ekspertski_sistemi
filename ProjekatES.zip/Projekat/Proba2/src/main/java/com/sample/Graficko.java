package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import java.awt.BorderLayout;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import javax.swing.SwingConstants;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Graficko {
	
	private static String nR1Vrednost;
	private static String nR3Vrednost;
	private static String nR5Vrednost;
	private static String nR7Vrednost;
	private static String nH1Vrednost;
	private static String nH3Vrednost;
	private static String nH5Vrednost;
	private static String o1Vrednost;
	private static String z1Vrednost;
	private static String h1Vrednost;
	private static String b1Vrednost;
	private static String vk1Vrednost;
	private static String vd1Vrednost;
	private static String emuvs1Vrednost;
	private static String pzi1Vrednost;
	private static String c1Vrednost;
	private static String ce1Vrednost;
	private static String odvod1Vrednost;
	private static String pr1Vrednost;
	private static String ipr1Vrednost;
	private static String tf1Vrednost;
	private static String term1Vrednost;
	private static String zl1Vrednost;
	private static String vf1Vrednost;
	private static String pv1Vrednost;
	
	
	
	
	public static final void main(String[] args) {
		
		JFrame pocetniProzor = new JFrame("Frizider");
		pocetniProzor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pocetniProzor.setSize(500, 500);
		
		JLabel textProblem = new JLabel("Izaberite problem: ");
		textProblem.setHorizontalAlignment(SwingConstants.CENTER);
		textProblem.setVerticalAlignment(SwingConstants.NORTH);
		Font font = new Font("Serif", Font.PLAIN, 24);
		textProblem.setFont(font);
		
		pocetniProzor.add(textProblem, BorderLayout.NORTH);
		
		
	    textProblem.setVisible(true);
		
		
		JRadioButton RB1B = new JRadioButton("Vas frizider ne radi");
		RB1B.setSelected(false);
	  
	    
	    JRadioButton RB2B = new JRadioButton("Vas frizider ne hladi");
	    RB2B.setSelected(false);

	    
	    JRadioButton RB3B = new JRadioButton("Vas frizider slabo hladi");

	    RB3B.setSelected(false);
	    
	    JRadioButton RB4B = new JRadioButton("Vas frizider je bucan");
	    RB4B.setSelected(false);
	    
	    JRadioButton RB5B = new JRadioButton("Curi voda iz frizidera");
	    RB5B.setSelected(false);
	    
	    JRadioButton RB6B = new JRadioButton("Hrana u frizideru se zamrzava");
	    RB6B.setSelected(false);
	    
	    JRadioButton RB7B = new JRadioButton("Unutar frizidera kaplje voda");
	    RB7B.setSelected(false);
	    
	    JRadioButton RB8B = new JRadioButton("Frizider neprekidno radi");
	    RB8B.setSelected(false);
	    
	    JRadioButton RB9B = new JRadioButton("Problem sa ledo-matom");
	    RB9B.setSelected(false);

	    
	   
	    JPanel radioPanel = new JPanel(new GridLayout(0, 2));

	    
	    radioPanel.add(RB1B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB2B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB3B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB4B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB5B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB6B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB7B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB8B);
	    radioPanel.add(new JLabel(""));
	    radioPanel.add(RB9B);
	    radioPanel.add(new JLabel(""));
	    

	    
	    pocetniProzor.add(radioPanel);

		pocetniProzor.setVisible(true);
		
		



		RB1B.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Ne radi");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            JLabel svetloOV= new JLabel("Da li se pali svetlo pri otvaranju vrata?");
	        	JRadioButton nR1 = new JRadioButton("da");
	        	nR1.setSelected(false);
	        	JRadioButton nR2 = new JRadioButton("ne");
	        	nR2.setSelected(false);
	        	
	        	JLabel zV= new JLabel("Da li se cuje zvuk ventilatora?");
	        	JRadioButton nR3 = new JRadioButton("da");
	        	nR3.setSelected(false);
	        	JRadioButton nR4 = new JRadioButton("ne");
	        	nR4.setSelected(false);
	        	
	        	JLabel zK= new JLabel("Da li se cuje zvuk kompresora?");
	        	JRadioButton nR5 = new JRadioButton("da");
	        	nR5.setSelected(false);
	        	JRadioButton nR6 = new JRadioButton("ne");
	        	nR6.setSelected(false);
	        	
	        	JLabel napajanje= new JLabel("Da li se frizider napaja strujom?");
	        	JRadioButton nR7 = new JRadioButton("da");
	        	nR7.setSelected(false);
	        	JRadioButton nR8 = new JRadioButton("ne");
	        	nR8.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel1 = new JPanel(new GridLayout(0, 2));
	        	radioPanel1.add(svetloOV);
	        	radioPanel1.add(new JLabel(""));
	        	radioPanel1.add(nR1);
	        	radioPanel1.add(nR2);
	        	
	        	radioPanel1.add(zV);
	        	radioPanel1.add(new JLabel(""));
	        	radioPanel1.add(nR3);
	        	radioPanel1.add(nR4);
	        	radioPanel1.add(zK);
	        	radioPanel1.add(new JLabel(""));
	        	radioPanel1.add(nR5);
	        	radioPanel1.add(nR6);
	        	radioPanel1.add(napajanje);
	        	radioPanel1.add(new JLabel(""));
	        	radioPanel1.add(nR7);
	        	radioPanel1.add(nR8);
	        	radioPanel1.add(problem);
	        	
	        	frame.add(radioPanel1);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(nR1.isSelected()) {
	        				nR1Vrednost = "da";
	        			}else if(nR2.isSelected()) {
	        				nR1Vrednost = "ne";
	        			}
	        			if(nR3.isSelected()) {
	        				nR3Vrednost = "da";
	        			}else if(nR4.isSelected()) {
	        				nR3Vrednost = "ne";
	        			}
	        			if(nR5.isSelected()) {
	        				nR5Vrednost = "da";
	        			}else if(nR6.isSelected()) {
	        				nR5Vrednost = "ne";
	        			}
	        			if(nR7.isSelected()) {
	        				nR7Vrednost = "da";
	        			}else if(nR8.isSelected()) {
	        				nR7Vrednost = "ne";
	        			}
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		
		RB2B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Ne hladi");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            JLabel napajanje= new JLabel("Da li se frizider napaja strujom?");
	        	JRadioButton nR7 = new JRadioButton("da");
	        	nR7.setSelected(false);
	        	JRadioButton nR8 = new JRadioButton("ne");
	        	nR8.setSelected(false);
	        	JLabel M= new JLabel("Da li je frizider 'mrtav'?");
	        	JRadioButton nH1 = new JRadioButton("da");
	        	nH1.setSelected(false);
	        	JRadioButton nH2 = new JRadioButton("ne");
	        	nH2.setSelected(false);
	        	
	        	JLabel termostat= new JLabel("Da li je termostat postavljen na ispravnu vrednost?");
	        	JRadioButton nH3 = new JRadioButton("ispravna vrednost");
	        	nH3.setSelected(false);
	        	JRadioButton nH4 = new JRadioButton("neispravna vrednost");
	        	nH4.setSelected(false);
	        	JLabel kompresor= new JLabel("Da li motor kompresora radi?");
	        	JRadioButton nH5 = new JRadioButton("da");
	        	nH5.setSelected(false);
	        	JRadioButton nH6 = new JRadioButton("ne");
	        	nH6.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel2 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel2.add(napajanje);
	        	radioPanel2.add(new JLabel(""));
	        	radioPanel2.add(nR7);
	        	radioPanel2.add(nR8);
	        	radioPanel2.add(M);
	        	radioPanel2.add(new JLabel(""));
	        	radioPanel2.add(nH1);
	        	radioPanel2.add(nH2);
	        	
	        	radioPanel2.add(termostat);
	        	radioPanel2.add(new JLabel(""));
	        	radioPanel2.add(nH3);
	        	radioPanel2.add(nH4);
	        	radioPanel2.add(kompresor);
	        	radioPanel2.add(new JLabel(""));
	        	radioPanel2.add(nH5);
	        	radioPanel2.add(nH6);
	        	
	        	radioPanel2.add(problem);
	        	
	        	frame.add(radioPanel2);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(nR7.isSelected()) {
	        				nR7Vrednost = "da";
	        			}else if(nR8.isSelected()) {
	        				nR7Vrednost = "ne";
	        			}
	        			if(nH1.isSelected()) {
	        				nH1Vrednost = "da";
	        			}else if(nH2.isSelected()) {
	        				nH1Vrednost = "ne";
	        			}
	        			if(nH3.isSelected()) {
	        				nH3Vrednost = "ispravna vrednost";
	        			}else if(nH4.isSelected()) {
	        				nH3Vrednost = "neispravna vrednost";
	        			}
	        			if(nH5.isSelected()) {
	        				nH5Vrednost = "da";
	        			}else if(nH6.isSelected()) {
	        				nH5Vrednost = "ne";
	        			}
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		
		
		RB3B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Hladjenje je slabo");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            
	            JLabel odmrzavanje= new JLabel("Da li je odmrznut frizider?");
	        	JRadioButton o1 = new JRadioButton("da");
	        	o1.setSelected(false);
	        	JRadioButton o2 = new JRadioButton("ne");
	        	o2.setSelected(false);
	        	
	        	JLabel zavojnice= new JLabel("Da li zavojnice imaju prljavstinu?");
	        	JRadioButton z1 = new JRadioButton("imaju prasinu");
	        	z1.setSelected(false);
	        	JRadioButton z2 = new JRadioButton("nemaju prasinu");
	        	z2.setSelected(false);
	        	JLabel hladjenje= new JLabel("Da li hladi frizider?");
	        	JRadioButton h1 = new JRadioButton("da");
	        	h1.setSelected(false);
	        	JRadioButton h2 = new JRadioButton("ne");
	        	h2.setSelected(false);
	        	JRadioButton h3 = new JRadioButton("ne hladi ispravno");
	        	h3.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel3 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel3.add(odmrzavanje);
	        	radioPanel3.add(new JLabel(""));
	        	radioPanel3.add(o1);
	        	radioPanel3.add(o2);
	        	radioPanel3.add(zavojnice);
	        	radioPanel3.add(new JLabel(""));
	        	radioPanel3.add(z1);
	        	radioPanel3.add(z2);
	        	radioPanel3.add(hladjenje);
	        	radioPanel3.add(new JLabel(""));
	        	radioPanel3.add(h1);
	        	radioPanel3.add(h2);
	        	
	        	radioPanel3.add(problem);
	        	
	        	frame.add(radioPanel3);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(o1.isSelected()) {
	        				o1Vrednost = "da";
	        			}else if(o2.isSelected()) {
	        				o1Vrednost = "ne";
	        			}
	        			if(z1.isSelected()) {
	        				z1Vrednost = "imaju prasinu";
	        			}else if(z2.isSelected()) {
	        				z1Vrednost = "nemaju prasinu";
	        			}
	        			if(h1.isSelected()) {
	        				h1Vrednost = "da";
	        			}else if(h2.isSelected()) {
	        				h1Vrednost = "ne";
	        			}else if(h3.isSelected()) {
	        				h1Vrednost = "ne hladi ispravno";
	        			}
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		RB4B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Bucan je");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            
	            JLabel buka= new JLabel("Da li se cuje buka?");
	        	JRadioButton b1 = new JRadioButton("veca kada su vrata otvorena");
	        	b1.setSelected(false);
	        	JRadioButton b2 = new JRadioButton("ne");
	        	b2.setSelected(false);
	        	JLabel ventKomp= new JLabel("Da li se cuje ventilator kompresora?");
	        	JRadioButton vk1 = new JRadioButton("da");
	        	vk1.setSelected(false);
	        	JRadioButton vk2 = new JRadioButton("ne");
	        	vk2.setSelected(false);
	        	JLabel lopticeVentilatora = new JLabel("Da li loptice ventilatora imaju prljavstinu?");
	        	JRadioButton vd1 = new JRadioButton("imaju naslage");
	        	vd1.setSelected(false);
	        	JRadioButton vd2 = new JRadioButton("nemaju naslage");
	        	vd2.setSelected(false);
	        	JLabel elektricniMotorUnutarVremenskogSklopa= new JLabel("Da li je elektricni motor unutar vremenskog sklopa bucan?");
	        	JRadioButton emuvs1 = new JRadioButton("bucan");
	        	emuvs1.setSelected(false);
	        	JRadioButton emuvs2 = new JRadioButton("ne");
	        	emuvs2.setSelected(false);
	        	JLabel posudaZaIsparavanje= new JLabel("Kakva je posuda za ispravanje?");
	        	JRadioButton pzi1 = new JRadioButton("zveci");
	        	pzi1.setSelected(false);
	        	JRadioButton pzi2 = new JRadioButton("busna je");
	        	pzi2.setSelected(false);
	        	JRadioButton pzi3 = new JRadioButton("pomaknuta je ili napukla");
	        	pzi3.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel4 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel4.add(buka);
	        	radioPanel4.add(new JLabel(""));
	        	radioPanel4.add(b1);
	        	radioPanel4.add(b2);
	        	radioPanel4.add(ventKomp);
	        	radioPanel4.add(new JLabel(""));
	        	radioPanel4.add(vk1);
	        	radioPanel4.add(vk2);
	        	radioPanel4.add(lopticeVentilatora);
	        	radioPanel4.add(new JLabel(""));
	        	radioPanel4.add(vd1);
	        	radioPanel4.add(vd2);
	        	radioPanel4.add(elektricniMotorUnutarVremenskogSklopa);
	        	radioPanel4.add(new JLabel(""));
	        	radioPanel4.add(emuvs1);
	        	radioPanel4.add(emuvs2);
	        	radioPanel4.add(posudaZaIsparavanje);
	        	radioPanel4.add(new JLabel(""));
	        	radioPanel4.add(pzi1);
	        	radioPanel4.add(pzi2);
	        	radioPanel4.add(pzi3);
	        	
	        	radioPanel4.add(problem);
	        	
	        	frame.add(radioPanel4);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(b1.isSelected()) {
	        				b1Vrednost = "veca kada su vrata otvorena";
	        			}else if(b2.isSelected()) {
	        				b1Vrednost = "ne";
	        			}
	        			if(vk1.isSelected()) {
	        				vk1Vrednost = "da";
	        			}else if(vk2.isSelected()) {
	        				vk1Vrednost = "ne";
	        			}
	        			if(vd1.isSelected()) {
	        				vd1Vrednost = "imaju naslage";
	        			}else if(vd2.isSelected()) {
	        				vd1Vrednost = "nemaju naslage";
	        			}
	        			if(emuvs1.isSelected()) {
	        				emuvs1Vrednost = "bucan";
	        			}else if(emuvs2.isSelected()) {
	        				emuvs1Vrednost = "ne";
	        			}
	        			if(pzi1.isSelected()) {
	        				pzi1Vrednost = "zveci";
	        			}else if(pzi2.isSelected()) {
	        				pzi1Vrednost = "busna je";
	        			}else if(pzi3.isSelected()) {
	        				pzi1Vrednost = "pomaknuta je ili napukla";
	        			}
	        			
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
			
		RB5B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Curi voda iz frizidera");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            
	            JLabel posudaZaIsparavanje= new JLabel("Kakva je posuda za ispravanje?");
	        	JRadioButton pzi1 = new JRadioButton("zveci");
	        	pzi1.setSelected(false);
	        	JRadioButton pzi2 = new JRadioButton("busna je");
	        	pzi2.setSelected(false);
	        	JRadioButton pzi3 = new JRadioButton("pomaknuta je ili napukla");
	        	pzi3.setSelected(false);
	        	JLabel curenje= new JLabel("Odakle voda curi?");
	        	JRadioButton c1 = new JRadioButton("iz donjeg dela prednje strane frizidera ili vrata zamrzivaca");
	        	c1.setSelected(false);
	        	JRadioButton c2 = new JRadioButton("sa zadnje strane frizidera kod ventila od ledomata");
	        	c2.setSelected(false);
	        	JRadioButton c3 = new JRadioButton("iz tela ventila");
	        	c3.setSelected(false);
	        	JRadioButton c4 = new JRadioButton("iz posude za ispravanje");
	        	c4.setSelected(false);
	        	JRadioButton c5 = new JRadioButton("sa gornje unutrasnje strane");
	        	c5.setSelected(false);
	        	JRadioButton c6 = new JRadioButton("sa zadnje unutrasnje strane");
	        	c6.setSelected(false);
	        	JRadioButton c7 = new JRadioButton("sa prednje strane frizidera");
	        	c7.setSelected(false);
	        	JRadioButton c8 = new JRadioButton("unutar frizidera");
	        	c8.setSelected(false);
	        	
	        	JLabel cev= new JLabel("U kakvom je stanju cev?");
	        	JRadioButton ce1 = new JRadioButton("zacepljena");
	        	ce1.setSelected(false);
	        	JRadioButton ce2 = new JRadioButton("nepravilno prikljucena i nije dobro povezana");
	        	ce2.setSelected(false);
	        	JLabel odvod= new JLabel("Da li je odvod zacepljen?");
	        	JRadioButton odvod1 = new JRadioButton("zacepljen");
	        	odvod1.setSelected(false);
	        	JRadioButton odvod2 = new JRadioButton("zacepljen ili blokiran");
	        	odvod2.setSelected(false);
	        	JLabel prekidac= new JLabel("U kakvom je polozaju prekidac?");
	        	JRadioButton pr1 = new JRadioButton("u polozaju ustede energije");
	        	pr1.setSelected(false);
	        	JRadioButton pr2 = new JRadioButton("nije u polozaju ustede energije");
	        	pr2.setSelected(false);
	        	JLabel instalacijaPremaRasprsivacu= new JLabel("U kom stanju je instalacija prema rasprsivacu?");
	        	JRadioButton ipr1 = new JRadioButton("curi");
	        	ipr1.setSelected(false);
	        	JRadioButton ipr2 = new JRadioButton("ne");
	        	ipr2.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel5 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel5.add(posudaZaIsparavanje);
	        	radioPanel5.add(new JLabel(""));
	        	radioPanel5.add(pzi1);
	        	radioPanel5.add(pzi2);
	        	radioPanel5.add(pzi3);
	        	radioPanel5.add(curenje);
	        	radioPanel5.add(new JLabel(""));
	        	radioPanel5.add(c1);
	        	radioPanel5.add(c2);
	        	radioPanel5.add(c3);
	        	radioPanel5.add(c4);
	        	radioPanel5.add(c5);
	        	radioPanel5.add(c6);
	        	radioPanel5.add(c7);
	        	radioPanel5.add(c8);
	        	radioPanel5.add(cev);
	        	radioPanel5.add(new JLabel(""));
	        	radioPanel5.add(ce1);
	        	radioPanel5.add(ce2);
	        	radioPanel5.add(odvod);
	        	radioPanel5.add(new JLabel(""));
	        	radioPanel5.add(odvod1);
	        	radioPanel5.add(odvod2);
	        	radioPanel5.add(prekidac);
	        	radioPanel5.add(new JLabel(""));
	        	radioPanel5.add(pr1);
	        	radioPanel5.add(pr2);
	        	radioPanel5.add(instalacijaPremaRasprsivacu);
	        	radioPanel5.add(new JLabel(""));
	        	radioPanel5.add(ipr1);
	        	radioPanel5.add(ipr2);
	        	
	        	radioPanel5.add(problem);
	        	
	        	frame.add(radioPanel5);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(pzi1.isSelected()) {
	        				pzi1Vrednost = "zveci";
	        			}else if(pzi2.isSelected()) {
	        				pzi1Vrednost = "busna je";
	        			}else if(pzi3.isSelected()) {
	        				pzi1Vrednost = "pomaknuta je ili napukla";
	        			}
	        			if(c1.isSelected()) {
	        				c1Vrednost = "iz donjeg dela prednje strane frizidera ili vrata zamrzivaca";
	        			}else if(c2.isSelected()) {
	        				c1Vrednost = "sa zadnje strane frizidera kod ventila od ledomata";
	        			}else if(c3.isSelected()) {
	        				c1Vrednost = "iz tela ventila";
	        			}else if(c4.isSelected()) {
	        				c1Vrednost = "iz posude za isparavanje";
	        			}else if(c5.isSelected()) {
	        				c1Vrednost = "sa gornje unutrasnje strane";
	        			}else if(c6.isSelected()) {
	        				c1Vrednost = "sa zadnje unutrasnje strane";
	        			}else if(c7.isSelected()) {
	        				c1Vrednost = "sa prednje strane frizidera";
	        			}else if(c8.isSelected()) {
	        				c1Vrednost = "unutar frizidera";
	        			}
	        			if(ce1.isSelected()) {
	        				ce1Vrednost = "zacepljena";
	        			}else if(ce2.isSelected()) {
	        				ce1Vrednost = "nepravilno prikljucena i nije dobro povezana";
	        			}
	        			if(odvod1.isSelected()) {
	        				odvod1Vrednost = "zacepljen";
	        			}else if(odvod2.isSelected()) {
	        				odvod1Vrednost = "zacepljen ili blokirana";
	        			}
	        			if(pr1.isSelected()) {
	        				pr1Vrednost = "u polozaju ustede energije";
	        			}else if(pr2.isSelected()) {
	        				pr1Vrednost = "nije u polozaju ustede energije";
	        			}
	        			if(ipr1.isSelected()) {
	        				ipr1Vrednost = "curi";
	        			}else if(ipr2.isSelected()) {
	        				ipr1Vrednost = "ne";
	        			}
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		RB6B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Hrana u frizideru se zamrzava");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            
	            JLabel temperaturaFrizidera= new JLabel("Kakva je temperatura u frizideru?");
	        	JRadioButton tf1 = new JRadioButton("blizu 2 stepena Celzijusa");
	        	tf1.setSelected(false);
	        	JRadioButton tf2 = new JRadioButton("varira od gornje police prema dnu gde je najhladnije");
	        	tf2.setSelected(false);
	        	JRadioButton tf3 = new JRadioButton("preniska");
	        	tf3.setSelected(false);
	        	JRadioButton tf4 = new JRadioButton("toplija od -12 do -11 stepeni Celzijusa");
	        	tf4.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel6 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel6.add(temperaturaFrizidera);
	        	radioPanel6.add(new JLabel(""));
	        	radioPanel6.add(tf1);
	        	radioPanel6.add(tf2);
	        	radioPanel6.add(tf3);
	        	radioPanel6.add(tf4);
	        	
	        	radioPanel6.add(problem);
	        	
	        	frame.add(radioPanel6);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(tf1.isSelected()) {
	        				tf1Vrednost = "blizu 2 stepena Celzijusa";
	        			}else if(tf2.isSelected()) {
	        				tf1Vrednost = "varira od gornje police prema dnu gde je najhladnije";
	        			}else if(tf3.isSelected()) {
	        				tf1Vrednost = "preniska";
	        			}else if(tf4.isSelected()) {
	        				tf1Vrednost = "toplije od -12 do -11 stepeni Celzijusa";
	        			}
	        			
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		RB7B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Unutar frizidera kaplje voda: ");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            
	            JLabel curenje= new JLabel("Odakle voda curi?");
	        	JRadioButton c1 = new JRadioButton("iz donjeg dela prednje strane frizidera ili vrata zamrzivaca");
	        	c1.setSelected(false);
	        	JRadioButton c2 = new JRadioButton("sa zadnje strane frizidera kod ventila od ledomata");
	        	c2.setSelected(false);
	        	JRadioButton c3 = new JRadioButton("iz tela ventila");
	        	c3.setSelected(false);
	        	JRadioButton c4 = new JRadioButton("iz posude za ispravanje");
	        	c4.setSelected(false);
	        	JRadioButton c5 = new JRadioButton("sa gornje unutrasnje strane");
	        	c5.setSelected(false);
	        	JRadioButton c6 = new JRadioButton("sa zadnje unutrasnje strane");
	        	c6.setSelected(false);
	        	JRadioButton c7 = new JRadioButton("sa prednje strane frizidera");
	        	c7.setSelected(false);
	        	JRadioButton c8 = new JRadioButton("unutar frizidera");
	        	c8.setSelected(false);
	        	
	        	JLabel cev= new JLabel("U kakvom je stanju cev?");
	        	JRadioButton ce1 = new JRadioButton("zacepljena");
	        	ce1.setSelected(false);
	        	JRadioButton ce2 = new JRadioButton("nepravilno prikljucena i nije dobro povezana");
	        	ce2.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel7 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel7.add(curenje);
	        	radioPanel7.add(new JLabel(""));
	        	radioPanel7.add(c1);
	        	radioPanel7.add(c2);
	        	radioPanel7.add(c3);
	        	radioPanel7.add(c4);
	        	radioPanel7.add(c5);
	        	radioPanel7.add(c6);
	        	radioPanel7.add(c7);
	        	radioPanel7.add(c8);
	        	radioPanel7.add(cev);
	        	radioPanel7.add(new JLabel(""));
	        	radioPanel7.add(ce1);
	        	radioPanel7.add(ce2);
	        	
	        	radioPanel7.add(problem);
	        	
	        	frame.add(radioPanel7);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(c1.isSelected()) {
	        				c1Vrednost = "iz donjeg dela prednje strane frizidera ili vrata zamrzivaca";
	        			}else if(c2.isSelected()) {
	        				c1Vrednost = "sa zadnje strane frizidera kod ventila od ledomata";
	        			}else if(c3.isSelected()) {
	        				c1Vrednost = "iz tela ventila";
	        			}else if(c4.isSelected()) {
	        				c1Vrednost = "iz posude za isparavanje";
	        			}else if(c5.isSelected()) {
	        				c1Vrednost = "sa gornje unutrasnje strane";
	        			}else if(c6.isSelected()) {
	        				c1Vrednost = "sa zadnje unutrasnje strane";
	        			}else if(c7.isSelected()) {
	        				c1Vrednost = "sa prednje strane frizidera";
	        			}else if(c8.isSelected()) {
	        				c1Vrednost = "unutar frizidera";
	        			}
	        			if(ce1.isSelected()) {
	        				ce1Vrednost = "zacepljena";
	        			}else if(ce2.isSelected()) {
	        				ce1Vrednost = "nepravilno prikljucena i nije dobro povezana";
	        			}
	        			
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		RB8B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Neprekidno radi: ");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            
	            JLabel temperaturaFrizidera= new JLabel("Kakva je temperatura u frizideru?");
	        	JRadioButton tf1 = new JRadioButton("blizu 2 stepena Celzijusa");
	        	tf1.setSelected(false);
	        	JRadioButton tf2 = new JRadioButton("varira od gornje police prema dnu gde je najhladnije");
	        	tf2.setSelected(false);
	        	JRadioButton tf3 = new JRadioButton("preniska");
	        	tf3.setSelected(false);
	        	JRadioButton tf4 = new JRadioButton("toplija od -12 do -11 stepeni Celzijusa");
	        	tf4.setSelected(false);
	        	
	        	JLabel termostatRadi= new JLabel("Da li termostat radi?");
	        	JRadioButton term1 = new JRadioButton("ne radi");
	        	term1.setSelected(false);
	        	JRadioButton term2 = new JRadioButton("radi");
	        	term2.setSelected(false);
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel8 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel8.add(temperaturaFrizidera);
	        	radioPanel8.add(new JLabel(""));
	        	radioPanel8.add(tf1);
	        	radioPanel8.add(tf2);
	        	radioPanel8.add(tf3);
	        	radioPanel8.add(tf4);
	        	radioPanel8.add(termostatRadi);
	        	radioPanel8.add(term1);
	        	radioPanel8.add(term2);
	        	
	        	radioPanel8.add(problem);
	        	
	        	frame.add(radioPanel8);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(tf1.isSelected()) {
	        				tf1Vrednost = "blizu 2 stepena Celzijusa";
	        			}else if(tf2.isSelected()) {
	        				tf1Vrednost = "varira od gornje police prema dnu gde je najhladnije";
	        			}else if(tf3.isSelected()) {
	        				tf1Vrednost = "preniska";
	        			}else if(tf4.isSelected()) {
	        				tf1Vrednost = "toplije od -12 do -11 stepeni Celzijusa";
	        			}
	        			if(term1.isSelected()) {
	        				term1Vrednost = "ne radi";
	        			}else if(term2.isSelected()) {
	        				term1Vrednost = "radi";
	        			}
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		RB9B.addActionListener(new ActionListener() {
			
			@Override
	        public void actionPerformed(ActionEvent e) {
	            JFrame frame = new JFrame ("Problemi sa ledomatom: ");
	            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	            frame.setSize(500, 500);
	            
	            JLabel temperaturaFrizidera= new JLabel("Kakva je temperatura u frizideru?");
	        	JRadioButton tf1 = new JRadioButton("blizu 2 stepena Celzijusa");
	        	tf1.setSelected(false);
	        	JRadioButton tf2 = new JRadioButton("varira od gornje police prema dnu gde je najhladnije");
	        	tf2.setSelected(false);
	        	JRadioButton tf3 = new JRadioButton("preniska");
	        	tf3.setSelected(false);
	        	JRadioButton tf4 = new JRadioButton("toplija od -12 do -11 stepeni Celzijusa");
	        	tf4.setSelected(false);
	        	
	        	JLabel termostatRadi= new JLabel("Da li termostat radi?");
	        	JRadioButton term1 = new JRadioButton("ne radi");
	        	term1.setSelected(false);
	        	JRadioButton term2 = new JRadioButton("radi");
	        	term2.setSelected(false);
	        	JLabel zicaLedomata= new JLabel("U kakvom je polozaju zica ledomata?");
	        	JRadioButton zl1 = new JRadioButton("u ispravnom polozaju");
	        	zl1.setSelected(false);
	        	JLabel vrataFrizidera= new JLabel("Kako dihtuju vrata frizidera?");
	        	JRadioButton vf1 = new JRadioButton("dobro dihtuju");
	        	vf1.setSelected(false);
	        	JRadioButton vf2 = new JRadioButton("ne dihtuju dobro");
	        	vf2.setSelected(false);
	        	JLabel protokVode= new JLabel("Kakav je protok vode?");
	        	JRadioButton pv1 = new JRadioButton("dobar");
	        	pv1.setSelected(false);
	        	JRadioButton pv2 = new JRadioButton("slab");
	        	pv2.setSelected(false);
	        	
	        	
	        	JButton problem = new JButton("Problem");
	        	problem.setHorizontalAlignment(SwingConstants.CENTER);
	        	
	        	JPanel radioPanel9 = new JPanel(new GridLayout(0, 2));
	        	
	        	radioPanel9.add(temperaturaFrizidera);
	        	radioPanel9.add(new JLabel(""));
	        	radioPanel9.add(tf1);
	        	radioPanel9.add(tf2);
	        	radioPanel9.add(tf3);
	        	radioPanel9.add(tf4);
	        	radioPanel9.add(termostatRadi);
	        	radioPanel9.add(term1);
	        	radioPanel9.add(term2);
	        	radioPanel9.add(zicaLedomata);
	        	radioPanel9.add(new JLabel(""));
	        	radioPanel9.add(zl1);
	        	radioPanel9.add(new JLabel(""));
	        	radioPanel9.add(vrataFrizidera);
	        	radioPanel9.add(new JLabel(""));
	        	radioPanel9.add(vf1);
	        	radioPanel9.add(vf2);
	        	//radioPanel.add(new JLabel(""));
	        	radioPanel9.add(protokVode);
	        	radioPanel9.add(new JLabel(""));
	        	radioPanel9.add(pv1);
	        	radioPanel9.add(pv2);
	        	radioPanel9.add(problem);
	        	
	        	
	        	frame.add(radioPanel9);
	        	
	        	problem.addActionListener(new ActionListener() {
	        		public void actionPerformed(ActionEvent arg0) {
	        			
	        			
	        			
	        			if(tf1.isSelected()) {
	        				tf1Vrednost = "blizu 2 stepena Celzijusa";
	        			}else if(tf2.isSelected()) {
	        				tf1Vrednost = "varira od gornje police prema dnu gde je najhladnije";
	        			}else if(tf3.isSelected()) {
	        				tf1Vrednost = "preniska";
	        			}else if(tf4.isSelected()) {
	        				tf1Vrednost = "toplije od -12 do -11 stepeni Celzijusa";
	        			}
	        			if(term1.isSelected()) {
	        				term1Vrednost = "ne radi";
	        			}else if(term2.isSelected()) {
	        				term1Vrednost = "radi";
	        			}
	        			
	        			
	        			
	        			try {
	        		        KieServices ks = KieServices.Factory.get();
	        	    	    KieContainer kContainer = ks.getKieClasspathContainer();
	        	        	KieSession kSession = kContainer.newKieSession("ksession-rules");
	        	        	
	        	        	FriziderRadi f1 = new FriziderRadi();
	        	        	Frizider f = new Frizider();
	        	        	
	        	        	f1.setSvetlo(nR1Vrednost);
	        	        	
	        	        	f1.setZvukKomp(nR5Vrednost);
	        	        	f1.setZvukVent(nR3Vrednost);
	        	        	
	        	        	f.setNapajanje(nR7Vrednost);
	        	        	f.setBuka(b1Vrednost);
	        	        	f.setCev(ce1Vrednost);
	        	        	f.setCurenje(c1Vrednost);
	        	        	f.setElektricniMotorUnutarVremenskogSklopa(emuvs1Vrednost);
	        	        	f.setHladiFrizider(h1Vrednost);
	        	        	f.setOdmzavanje(o1Vrednost);
	        	        	f.setInstalacijaPremaRasprsivacu(ipr1Vrednost);
	        	        	f.setLopticeVentilatora(vd1Vrednost);
	        	        	f.setMotorKompresor(nH5Vrednost);
	        	        	f.setMrtavFrizider(nH1Vrednost);
	        	        	f.setOdvod(odvod1Vrednost);
	        	        	f.setPosudaZaIsparavanje(pzi1Vrednost);
	        	        	f.setPrekidac(pr1Vrednost);
	        	        	f.setProtokVode(pv1Vrednost);
	        	        	f.setTemperaturaFrizidera(tf1Vrednost);
	        	        	f.setTermostat(nH3Vrednost);
	        	        	
	        	        	f.setVentKond(vk1Vrednost);
	        	        	f.setVrataFrizidera(vf1Vrednost);
	        	        	f.setVrednostTermostata(term1Vrednost);
	        	        	f.setZavojnice(z1Vrednost);
	        	        	f.setZicaLedomata(zl1Vrednost);
	        	        
	        	        	
	        	        	
	        	        	kSession.insert(f1);
	        	        	kSession.insert(f);
	        	        	kSession.fireAllRules();
	        	        	if(f1.getProblem() == null) {
	        	        		f1.setProblem("Frizider radi");
	        	        	}
	        	        	System.out.println(f1);
	        	        	System.out.println(f);
	        	        	JOptionPane.showMessageDialog(null, f.getProblem());
	        	        	JOptionPane.showMessageDialog(null, f1.getProblem());
	        			}
	        			catch (Throwable t) {
	        	            t.printStackTrace();
	        	        }
	        		}
	        	});
	        	
	        	
	        	
	        	
	            frame.pack();
	            frame.setVisible (true);
	            

	        }
	    });
		
		
		
		
	
	
	}
}
